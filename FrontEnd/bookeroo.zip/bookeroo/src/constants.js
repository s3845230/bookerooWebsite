// AWS Deployment Address:
export const AUTHMICROSERVICE_IP = "http://authmicroservice-lb-1717063688.ap-southeast-2.elb.amazonaws.com";
// Local Development Address:
// export const AUTHMICROSERVICE_IP = "http://localhost:8080";