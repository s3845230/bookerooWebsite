export const GET_ERRORS = "GET_ERRORS";
export const GET_ALL_BOOKS = "GET_ALL_BOOKS";
export const GET_BOOKS = "GET_BOOKS";
export const SET_CURRENT_USER = "SET_CURRENT_USER";
export const GET_CURRENT_ROLE = "GET_CURRENT_ROLE";